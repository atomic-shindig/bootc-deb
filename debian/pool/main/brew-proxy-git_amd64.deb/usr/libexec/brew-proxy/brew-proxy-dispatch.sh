#!/bin/sh

# SPDX-FileCopyrightText: (c) 2026 brew-proxy contributors <https://codeberg.org/HastD/brew-proxy>
#
# SPDX-License-Identifier: Apache-2.0 OR MIT

# This wrapper script is part of the `homebrew-proxy` package.
#
# It forwards calls to `brew` by users other than the dedicated `linuxbrew` user
# to the `brew-proxy` program, which allows authorized users to execute brew
# commands as the `linuxbrew` user via a DBus-activated service.
#
# For more info, see: https://codeberg.org/HastD/brew-proxy

set -eu

if [ -z "${NO_BREW_PROXY-}" ] && [ -x /usr/bin/brew-proxy ] && [ "$(id -nu)" != 'linuxbrew' ]; then
  exec /usr/bin/brew-proxy "$@"
else
  exec /home/linuxbrew/.linuxbrew/proxy/brew-original "$@"
fi
