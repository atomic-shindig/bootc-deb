# SPDX-FileCopyrightText: (c) 2026 brew-proxy contributors <https://codeberg.org/HastD/brew-proxy>
#
# SPDX-License-Identifier: Apache-2.0 OR MIT

if type -fq brew-proxy && not fish_is_root_user
    if not set -g -x -q XDG_DATA_DIRS
        set -g -x XDG_DATA_DIRS /home/linuxbrew/.local/share /usr/local/share /usr/share
    else if not contains /home/linuxbrew/.local/share (string split : "$XDG_DATA_DIRS")
        set -g -x -p XDG_DATA_DIRS /home/linuxbrew/.local/share
    end
end
