# SPDX-FileCopyrightText: (c) 2026 brew-proxy contributors <https://codeberg.org/HastD/brew-proxy>
#
# SPDX-License-Identifier: Apache-2.0 OR MIT

which brew-proxy > /dev/null
if ( $? == 0 && $uid != 0 ) then
    if ( ${?XDG_DATA_DIRS} ) then
        switch ( "${XDG_DATA_DIRS}" )
        case "":
            setenv XDG_DATA_DIRS /home/linuxbrew/.local/share:/usr/local/share/:/usr/share/
        case "/home/linuxbrew/.local/share:"*:
            breaksw
        case *":/home/linuxbrew/.local/share:"*:
            breaksw
        default:
            setenv XDG_DATA_DIRS "/home/linuxbrew/.local/share:${XDG_DATA_DIRS}"
            breaksw
        endsw
    else
        setenv XDG_DATA_DIRS /home/linuxbrew/.local/share:/usr/local/share/:/usr/share/
    endif
endif
