# shellcheck shell=sh

# SPDX-FileCopyrightText: (c) 2026 brew-proxy contributors <https://codeberg.org/HastD/brew-proxy>
#
# SPDX-License-Identifier: Apache-2.0 OR MIT

if command -v brew-proxy >/dev/null && [ "$(id -u)" != 0 ]; then
  case "${XDG_DATA_DIRS-}" in
    /home/linuxbrew/.local/share:*|*:/home/linuxbrew/.local/share:*)
      ;;
    *)
      XDG_DATA_DIRS="/home/linuxbrew/.local/share:${XDG_DATA_DIRS:-/usr/local/share/:/usr/share/}"
      export XDG_DATA_DIRS
      ;;
  esac
fi
